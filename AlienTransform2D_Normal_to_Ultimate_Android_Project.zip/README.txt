ALIEN TRANSFORM 2D - NORMAL + ULTIMATE EVOLUTION

GAME MODES
- NORMAL: Swampfire, Big Chill, Way Big, Alien X, Four Arms.
- ULTIMATE: official Ultimate roster plus clearly marked custom fan-made forms.

NEW NORMAL -> ULTIMATE EVOLUTION
1. Choose NORMAL mode.
2. Select one of the five normal aliens.
3. Tap TRANSFORM.
4. Tap ULTIMATE to evolve that selected alien:
   Swampfire -> Ultimate Swampfire
   Big Chill -> Custom Ultimate Big Chill
   Way Big -> Custom Ultimate Way Big
   Alien X -> Custom Ultimate Alien X
   Four Arms -> Custom Ultimate Four Arms
5. Tap HUMAN to return to human form.

The Ultimate roster also remains directly selectable from ULTIMATE mode.
Touch controls: left, right, jump, power.

BUILD
This is an Android Studio Gradle source project, not a compiled APK.
Open in a compatible Android IDE, sync/build, and generate APK.
